import requests
import re
from bs4 import BeautifulSoup
import os



class PriceTracer:
    
    def __init__(self, url):
        self.url = url

        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
            "Accept-Language": "en-IN,en;q=0.9"
        }

        self.response = requests.get(url, headers=self.headers)

        self.soup = BeautifulSoup(self.response.text, "html.parser")
        
    def product_image(self):
        image = self.soup.find("img", id="landingImage")

        if image:
            image_url = image.get("src")

            # Create Images folder if it doesn't exist
            folder = "Images"
            os.makedirs(folder, exist_ok=True)

            # Product title as image name
            title = self.product_title()

            # Remove invalid filename characters
            file_name = re.sub(r'[\\/*?:"<>|]', "", title) + ".jpg"

            # Complete file path
            file_path = os.path.join(folder, file_name)

            # Download image
            response = requests.get(image_url)

            if response.status_code == 200:
                with open(file_path, "wb") as file:
                    file.write(response.content)

                print("Image saved in:", file_path)
            else:
                print("Image download failed.")

            return image_url

        else:
            return None
        
    def product_title(self):

        title = self.soup.find("span", id="productTitle")

        if title is not None:
            return title.text.strip() 
        else:
            return "Tag Not Found"

    def product_price(self):
        price = self.soup.find("span", class_ ="a-price-whole")

        if price is not None:
            return price.text.strip() 
        else:
            return "Tag Not Found"
    
    

device = PriceTracer("https://www.amazon.in/Titan-Karishma-Stainless-Watch-NL1639SM02-NN1639SM02/dp/B00ISNVQMW/")

print("Title :", device.product_title())
print("Price :", device.product_price())
print("Image :", device.product_image())

watch2 = PriceTracer("https://www.amazon.in/Titan-Multi-Colour-Stainless-Watch-NL1639SM01-NN1639SM01/dp/B00ISNVM0S/ref=pd_bxgy_d_sccl_1/522-2943323-9752964?pd_rd_w=thWQp&content-id=amzn1.sym.e933bed8-66b5-4e19-9aeb-b2834144fba3&pf_rd_p=e933bed8-66b5-4e19-9aeb-b2834144fba3&pf_rd_r=9AXVP2YPWWMBFBJGJC9M&pd_rd_wg=bWjYV&pd_rd_r=f53e10a9-a756-42a2-9969-5994232f51b5&pd_rd_i=B00ISNVM0S&psc=1")

print("Title :", watch2.product_title())
print("Price :", watch2.product_price())
print("Image :", watch2.product_image())

watch3 = PriceTracer("https://www.amazon.in/Titan-Quartz-Analog-Stainless-Women-NN2598SM01/dp/B07CQ1RZD7/ref=pd_bxgy_d_sccl_2/522-2943323-9752964?pd_rd_w=J3wsk&content-id=amzn1.sym.e933bed8-66b5-4e19-9aeb-b2834144fba3&pf_rd_p=e933bed8-66b5-4e19-9aeb-b2834144fba3&pf_rd_r=VZFKQ0XHM39PZ6TP0HV7&pd_rd_wg=VFzyN&pd_rd_r=0b39780e-fdd9-4ee5-b932-0d0072c9ad2f&pd_rd_i=B07CQ1RZD7&th=1")

print("Title :", watch3.product_title())
print("Price :", watch3.product_price())
print("Image :", watch3.product_image())