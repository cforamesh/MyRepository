from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet
from rest_framework.permissions import IsAuthenticated
from rest_framework import filters

from .models import Post
from .serializers import PostSerializer
from .permissions import IsPostPossessor
from helloworld.filters import PostFilter

from django_filters.rest_framework import DjangoFilterBackend


class HelloWorldView(APIView):
    """
    Simple API endpoint that returns a greeting message.
    """

    def get(self, request, *args, **kwargs):
        return Response({
            "message": "Hello World!"
        })


class PostView(ModelViewSet):
    """
    CRUD API for Post model.
    Only authenticated users can access this endpoint.
    """

    queryset = Post.objects.all()
    serializer_class = PostSerializer
    permission_classes = (IsAuthenticated, IsPostPossessor)
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = PostFilter
    search_fields = ["title", "content"]
    ordering_fields = ["id"]
    
    def get_queryset(self):
        return Post.objects.filter(created_by = self.request.user)
    