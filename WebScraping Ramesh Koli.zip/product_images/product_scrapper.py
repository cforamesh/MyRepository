"""
Product Web Scraper: Extracts product title, price, and image from product page URLs,
downloads the product image, and compares the price against a target price.
"""

import os
import re
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin


HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Safari/537.36"
    )
}

IMAGE_DIR = "product_images"


def fetch_page(url, timeout=10):
    """Fetch raw HTML for a given URL. Returns None on failure."""
    try:
        response = requests.get(url, headers=HEADERS, timeout=timeout)
        response.raise_for_status()
        return response.text
    except requests.RequestException as e:
        print(f"[ERROR] Could not fetch {url}: {e}")
        return None


def extract_product_details(url):
    html = fetch_page(url)
    if html is None:
        return None

    soup = BeautifulSoup(html, "html.parser")

    # ---- Title ----
    title_tag = soup.select_one("div.product_main h1")
    title = title_tag.get_text(strip=True) if title_tag else None

    # ---- Price ----
    price_tag = soup.select_one("p.price_color")
    price = None
    if price_tag:
        # Strip currency symbols/commas, keep digits and decimal point
        price_text = price_tag.get_text(strip=True)
        match = re.search(r"[\d,.]+", price_text)
        if match:
            price = float(match.group().replace(",", ""))

    # ---- Image URL ----
    img_tag = soup.select_one("div.item.active img") or soup.select_one("#product_gallery img")
    image_url = urljoin(url, img_tag["src"]) if img_tag and img_tag.get("src") else None

    if not title or price is None or not image_url:
        print(f"[WARN] Incomplete data extracted from {url}")

    return {
        "url": url,
        "title": title,
        "price": price,
        "image_url": image_url,
    }


def download_image(image_url, title, folder=IMAGE_DIR):
    """Download the product image to a local folder. Returns saved path or None."""
    if not image_url:
        return None

    os.makedirs(folder, exist_ok=True)

    try:
        response = requests.get(image_url, headers=HEADERS, timeout=10)
        response.raise_for_status()
    except requests.RequestException as e:
        print(f"[ERROR] Could not download image from {image_url}: {e}")
        return None

    # Build a safe filename from the title
    safe_name = re.sub(r"[^\w\-]+", "_", title.strip()) if title else "product"
    ext = os.path.splitext(image_url)[1].split("?")[0] or ".jpg"
    filepath = os.path.join(folder, f"{safe_name}{ext}")

    with open(filepath, "wb") as f:
        f.write(response.content)

    return filepath


def compare_price(actual_price, target_price):
    """Compare actual product price against a target price."""
    if actual_price is None:
        return "Price unavailable — cannot compare."
    if actual_price < target_price:
        return f"Below target! (£{actual_price:.2f} < £{target_price:.2f}) — good buy."
    elif actual_price > target_price:
        return f"Above target. (£{actual_price:.2f} > £{target_price:.2f}) — wait for a drop."
    else:
        return f"Exactly at target price (£{actual_price:.2f})."


def process_products(urls, target_price):
    """Run the full pipeline over multiple product URLs and print a report."""
    results = []

    for url in urls:
        print("=" * 70)
        print(f"Fetching: {url}")
        details = extract_product_details(url)

        if details is None:
            print("Skipped due to fetch error.\n")
            continue

        image_path = download_image(details["image_url"], details["title"])
        comparison = compare_price(details["price"], target_price)

        details["local_image_path"] = image_path
        details["price_comparison"] = comparison
        results.append(details)

        print(f"Title       : {details['title']}")
        print(f"Price       : £{details['price']:.2f}" if details["price"] is not None else "Price       : N/A")
        print(f"Image URL   : {details['image_url']}")
        print(f"Image saved : {image_path if image_path else 'download failed'}")
        print(f"Comparison  : {comparison}")

    print("=" * 70)
    return results


if __name__ == "__main__":

    product_urls = [
        "https://books.toscrape.com/catalogue/a-light-in-the-attic_1000/index.html",
        "https://books.toscrape.com/catalogue/soumission_998/index.html",
        "https://books.toscrape.com/catalogue/sharp-objects_997/index.html",
    ]

    TARGET_PRICE = 50.00  # set your target price here

    process_products(product_urls, TARGET_PRICE)